Run migrations with: alembic revision --autogenerate -m "init" && alembic upgrade head
