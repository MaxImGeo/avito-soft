#!/usr/bin/env bash
set -euo pipefail

SET_V4="cloudflare4"
SET_V6="cloudflare6"

ensure_set() {
  local name="$1"
  local family="$2"
  if ! ipset list -n | grep -q "^${name}$"; then
    ipset create "$name" hash:net family "$family" maxelem 20000
  fi
}

tmp_v4="$(mktemp)"
tmp_v6="$(mktemp)"
curl -fsSL https://www.cloudflare.com/ips-v4 > "$tmp_v4"
curl -fsSL https://www.cloudflare.com/ips-v6 > "$tmp_v6"

ensure_set "$SET_V4" inet
ensure_set "$SET_V6" inet6

# Flush and load
ipset flush "$SET_V4"
ipset flush "$SET_V6"

while read -r cidr; do
  [[ -z "$cidr" ]] && continue
  ipset add "$SET_V4" "$cidr" || true
done < "$tmp_v4"

while read -r cidr; do
  [[ -z "$cidr" ]] && continue
  ipset add "$SET_V6" "$cidr" || true
done < "$tmp_v6"

rm -f "$tmp_v4" "$tmp_v6"
echo "Updated ipset Cloudflare lists."
