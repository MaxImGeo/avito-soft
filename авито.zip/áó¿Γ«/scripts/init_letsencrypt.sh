#!/usr/bin/env sh
set -e

if [ -z "${DOMAIN}" ]; then
  echo "DOMAIN is required"
  exit 1
fi

if [ -z "${ADMIN_DOMAIN}" ]; then
  echo "ADMIN_DOMAIN is required"
  exit 1
fi

if [ -z "${LETSENCRYPT_EMAIL}" ]; then
  echo "LETSENCRYPT_EMAIL is required"
  exit 1
fi

echo "==> Creating/renewing certificate for ${DOMAIN}"

# Ensure nginx is up on :80 for challenge
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml up -d nginx

# Request cert (webroot)
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml run --rm certbot certonly       --webroot -w /var/www/certbot       -d "${DOMAIN}"       --email "${LETSENCRYPT_EMAIL}"       --agree-tos --no-eff-email       --rsa-key-size 2048

echo "==> Reload nginx"
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml exec nginx nginx -s reload

echo "Done."
