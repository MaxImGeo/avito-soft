#!/usr/bin/env bash
set -euo pipefail

echo "==> Installing ipset if needed"
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y
  sudo apt-get install -y ipset iptables-persistent || true
fi

echo "==> Updating ipset lists"
sudo bash scripts/update_cloudflare_ipset.sh

echo "==> Adding iptables rules for 80/443 to only allow Cloudflare"
# IPv4
sudo iptables -C INPUT -p tcp --dport 80 -m set --match-set cloudflare4 src -j ACCEPT 2>/dev/null || sudo iptables -I INPUT -p tcp --dport 80 -m set --match-set cloudflare4 src -j ACCEPT
sudo iptables -C INPUT -p tcp --dport 443 -m set --match-set cloudflare4 src -j ACCEPT 2>/dev/null || sudo iptables -I INPUT -p tcp --dport 443 -m set --match-set cloudflare4 src -j ACCEPT
sudo iptables -C INPUT -p tcp --dport 80 -j DROP 2>/dev/null || sudo iptables -A INPUT -p tcp --dport 80 -j DROP
sudo iptables -C INPUT -p tcp --dport 443 -j DROP 2>/dev/null || sudo iptables -A INPUT -p tcp --dport 443 -j DROP

# IPv6
if command -v ip6tables >/dev/null 2>&1; then
  sudo ip6tables -C INPUT -p tcp --dport 80 -m set --match-set cloudflare6 src -j ACCEPT 2>/dev/null || sudo ip6tables -I INPUT -p tcp --dport 80 -m set --match-set cloudflare6 src -j ACCEPT
  sudo ip6tables -C INPUT -p tcp --dport 443 -m set --match-set cloudflare6 src -j ACCEPT 2>/dev/null || sudo ip6tables -I INPUT -p tcp --dport 443 -m set --match-set cloudflare6 src -j ACCEPT
  sudo ip6tables -C INPUT -p tcp --dport 80 -j DROP 2>/dev/null || sudo ip6tables -A INPUT -p tcp --dport 80 -j DROP
  sudo ip6tables -C INPUT -p tcp --dport 443 -j DROP 2>/dev/null || sudo ip6tables -A INPUT -p tcp --dport 443 -j DROP
fi

echo "==> Saving rules (best-effort)"
if command -v netfilter-persistent >/dev/null 2>&1; then
  sudo netfilter-persistent save
elif command -v iptables-save >/dev/null 2>&1; then
  sudo sh -c 'iptables-save > /etc/iptables/rules.v4' || true
  sudo sh -c 'ip6tables-save > /etc/iptables/rules.v6' || true
fi

echo "Done. Now only Cloudflare can reach ports 80/443."
echo "IMPORTANT: keep SSH open (22) so you don't lock yourself out."
