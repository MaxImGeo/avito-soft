#!/usr/bin/env sh
set -e

echo "==> Pull latest (if repo) and rebuild"
if [ -d .git ]; then
  git pull --rebase
fi

docker compose -f docker-compose.prod.yml -f docker-compose.https.yml build
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml up -d --remove-orphans

echo "==> Prune dangling images"
docker image prune -f

echo "Done."
