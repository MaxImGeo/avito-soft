#!/usr/bin/env bash
set -euo pipefail

echo "==> Re-enabling Cloudflare-only rules (80/443)"
chmod +x scripts/update_cloudflare_ipset.sh scripts/setup_cloudflare_firewall.sh
sudo ./scripts/setup_cloudflare_firewall.sh
