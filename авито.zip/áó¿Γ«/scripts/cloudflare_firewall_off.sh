#!/usr/bin/env bash
set -euo pipefail

echo "==> Removing Cloudflare-only DROP rules (80/443 open to the world)"
# IPv4
sudo iptables -D INPUT -p tcp --dport 80 -j DROP 2>/dev/null || true
sudo iptables -D INPUT -p tcp --dport 443 -j DROP 2>/dev/null || true

# IPv6
if command -v ip6tables >/dev/null 2>&1; then
  sudo ip6tables -D INPUT -p tcp --dport 80 -j DROP 2>/dev/null || true
  sudo ip6tables -D INPUT -p tcp --dport 443 -j DROP 2>/dev/null || true
fi

echo "Done. Ports 80/443 are no longer Cloudflare-only."
