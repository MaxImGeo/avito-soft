#!/usr/bin/env sh
set -e

TS=$(date +"%Y%m%d_%H%M%S")
OUT="backup_${TS}.sql.gz"

echo "==> Backup postgres -> ${OUT}"
docker compose -f docker-compose.prod.yml exec -T postgres pg_dump -U postgres -d avito | gzip > "${OUT}"
echo "Done."
