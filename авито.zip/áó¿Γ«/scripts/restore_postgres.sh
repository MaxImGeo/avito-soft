#!/usr/bin/env sh
set -e

if [ -z "$1" ]; then
  echo "Usage: ./scripts/restore_postgres.sh backup_YYYYMMDD_HHMMSS.sql.gz"
  exit 1
fi

IN="$1"
echo "==> Restore postgres from ${IN}"
gunzip -c "${IN}" | docker compose -f docker-compose.prod.yml exec -T postgres psql -U postgres -d avito
echo "Done."
