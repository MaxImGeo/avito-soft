#!/usr/bin/env sh
set -e
echo "==> Disabling maintenance mode"
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml exec nginx sh -c "rm -f /etc/nginx/maintenance/on || true"
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml exec nginx nginx -s reload
echo "Done."
