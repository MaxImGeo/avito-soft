#!/usr/bin/env sh
set -e

OUT="nginx/conf.d/realip_cloudflare.conf"
TMP="$(mktemp)"

echo "# generated $(date -u) UTC" > "$TMP"
echo "" >> "$TMP"

# Cloudflare publishes IP lists here:
# - https://www.cloudflare.com/ips-v4
# - https://www.cloudflare.com/ips-v6
#
# We fetch them and convert into nginx `set_real_ip_from` directives.
for url in "https://www.cloudflare.com/ips-v4" "https://www.cloudflare.com/ips-v6"; do
  echo "Fetching $url"
  curl -fsSL "$url" | while read -r cidr; do
    [ -z "$cidr" ] && continue
    echo "set_real_ip_from $cidr;" >> "$TMP"
  done
done

echo "" >> "$TMP"
echo "# required with Cloudflare" >> "$TMP"
echo "real_ip_header CF-Connecting-IP;" >> "$TMP"
echo "real_ip_recursive on;" >> "$TMP"

mv "$TMP" "$OUT"
echo "Wrote $OUT"
