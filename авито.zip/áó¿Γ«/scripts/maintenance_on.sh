#!/usr/bin/env sh
set -e
echo "==> Enabling maintenance mode"
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml exec nginx sh -c "mkdir -p /etc/nginx/maintenance && touch /etc/nginx/maintenance/on"
docker compose -f docker-compose.prod.yml -f docker-compose.https.yml exec nginx nginx -s reload
echo "Done."
