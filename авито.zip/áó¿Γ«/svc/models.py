from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime, timezone

from .db import Base

def utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(sa.BigInteger, primary_key=True, autoincrement=True)
    tg_user_id: Mapped[int] = mapped_column(sa.BigInteger, unique=True, index=True)
    tg_chat_id: Mapped[int] = mapped_column(sa.BigInteger, index=True)
    username: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), default=utcnow)

    subscriptions: Mapped[list["Subscription"]] = relationship(back_populates="user")
    watches: Mapped[list["Watch"]] = relationship(back_populates="user")

class Plan(Base):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(sa.BigInteger, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(sa.String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(sa.String(64))
    max_watches: Mapped[int] = mapped_column(sa.Integer)
    min_interval_sec: Mapped[int] = mapped_column(sa.Integer)
    price_rub_month: Mapped[int] = mapped_column(sa.Integer)
    max_rps: Mapped[int] = mapped_column(sa.Integer, default=1)

class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(sa.BigInteger, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(sa.BigInteger, sa.ForeignKey("users.id"), index=True)
    plan_id: Mapped[int] = mapped_column(sa.BigInteger, sa.ForeignKey("plans.id"), index=True)
    status: Mapped[str] = mapped_column(sa.String(16), index=True)  # active | canceled | pending
    current_period_end: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), default=utcnow)

    user: Mapped["User"] = relationship(back_populates="subscriptions")
    plan: Mapped["Plan"] = relationship()

class Watch(Base):
    __tablename__ = "watches"

    id: Mapped[int] = mapped_column(sa.BigInteger, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(sa.BigInteger, sa.ForeignKey("users.id"), index=True)
    url: Mapped[str] = mapped_column(sa.Text)
    interval_sec: Mapped[int] = mapped_column(sa.Integer)
    enabled: Mapped[bool] = mapped_column(sa.Boolean, default=True, index=True)

    next_run_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), default=utcnow, index=True)
    locked_until: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True, index=True)
    locked_by: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)

    fail_count: Mapped[int] = mapped_column(sa.Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    last_success_at: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), default=utcnow)

    user: Mapped["User"] = relationship(back_populates="watches")
    items: Mapped[list["Item"]] = relationship(back_populates="watch")

    __table_args__ = (
        sa.Index("idx_watches_due", "enabled", "next_run_at"),
    )

class Item(Base):
    __tablename__ = "items"

    id: Mapped[int] = mapped_column(sa.BigInteger, primary_key=True, autoincrement=True)
    watch_id: Mapped[int] = mapped_column(sa.BigInteger, sa.ForeignKey("watches.id"), index=True)
    item_id: Mapped[str] = mapped_column(sa.String(128))
    title: Mapped[str] = mapped_column(sa.Text)
    price: Mapped[str] = mapped_column(sa.String(64))
    url: Mapped[str] = mapped_column(sa.Text)
    first_seen_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), default=utcnow, index=True)

    watch: Mapped["Watch"] = relationship(back_populates="items")

    __table_args__ = (
        sa.UniqueConstraint("watch_id", "item_id", name="uq_item_watch_itemid"),
        sa.Index("idx_items_watch_seen", "watch_id", "first_seen_at"),
    )


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(sa.BigInteger, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(sa.BigInteger, sa.ForeignKey("users.id"), index=True)
    plan_id: Mapped[int] = mapped_column(sa.BigInteger, sa.ForeignKey("plans.id"), index=True)

    provider: Mapped[str] = mapped_column(sa.String(32))  # yookassa | stub
    provider_payment_id: Mapped[str | None] = mapped_column(sa.String(128), nullable=True, index=True)
    status: Mapped[str] = mapped_column(sa.String(16), index=True)  # pending|succeeded|canceled

    amount_value: Mapped[str] = mapped_column(sa.String(32))
    currency: Mapped[str] = mapped_column(sa.String(8), default="RUB")

    pay_url: Mapped[str] = mapped_column(sa.Text)
    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), default=utcnow)

    __table_args__ = (
        sa.Index("idx_payments_provider_pid", "provider", "provider_payment_id"),
    )
