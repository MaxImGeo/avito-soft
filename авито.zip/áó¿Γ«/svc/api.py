from __future__ import annotations

import logging
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import sqlalchemy as sa

from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

from .db import engine, SessionLocal, Base
from .config import settings
from .security import require_service_key, require_admin_key
from .schemas import (
    UpsertUserIn, UserOut, PlanOut,
    WatchCreateIn, WatchOut, WatchIntervalIn, WatchDeleteIn,
    PaymentCreateIn, PaymentCreateOut
)
from .models import User, Plan, Subscription, Watch
from .seed import seed_plans
from . import repo
from .payments.factory import create_payment as create_provider_payment
from .payments.yookassa import get_payment as yk_get_payment

log = logging.getLogger("api")

app = FastAPI(title="Avito Monitor PRO", version="1.1.0")

REQ_COUNTER = Counter('api_requests_total', 'Total API requests', ['path', 'method'])
REQ_TIME = Histogram('api_request_duration_seconds', 'API request duration', ['path'])
templates = Jinja2Templates(directory="templates")

import ipaddress


def ip_in_allowlist(ip: str, allowlist: str) -> bool:
    """allowlist: comma-separated IP/CIDR. empty => allow."""
    if not allowlist:
        return True
    try:
        addr = ipaddress.ip_address(ip)
    except Exception:
        return False
    parts = [p.strip() for p in allowlist.split(",") if p.strip()]
    for p in parts:
        try:
            net = ipaddress.ip_network(p, strict=False)
            if addr in net:
                return True
        except Exception:
            # maybe plain ip
            try:
                if addr == ipaddress.ip_address(p):
                    return True
            except Exception:
                continue
    return False


def get_client_ip(request: Request) -> str:
    """Return best-effort real client IP behind reverse proxies.

    Priority:
    - X-Real-IP
    - first IP from X-Forwarded-For
    - request.client.host
    """
    xr = request.headers.get("x-real-ip")
    if xr:
        return xr.strip()
    xff = request.headers.get("x-forwarded-for")
    if xff:
        # may contain 'client, proxy1, proxy2'
        first = xff.split(",")[0].strip()
        if first:
            return first
    return request.client.host if request.client else ""


@app.on_event("startup")
async def on_startup() -> None:
    # Create tables (for MVP). For production use Alembic migrations.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with SessionLocal() as session:
        await seed_plans(session)
    log.info("Startup done")
    import asyncio
    asyncio.create_task(sub_reaper_loop())



@app.middleware("http")
async def metrics_mw(request: Request, call_next):
    path = request.url.path
    REQ_COUNTER.labels(path=path, method=request.method).inc()
    with REQ_TIME.labels(path=path).time():
        return await call_next(request)





async def sub_reaper_loop() -> None:
    """Downgrade expired subscriptions back to free (runs in API process)."""
    import asyncio
    from datetime import datetime, timezone
    import sqlalchemy as sa
    from .models import Subscription, User, Plan
    from .seed import ensure_free_subscription

    while True:
        try:
            now = datetime.now(tz=timezone.utc)
            async with SessionLocal() as session:
                # find subs expired and active
                subs = await session.scalars(
                    sa.select(Subscription)
                      .where(Subscription.status == "active", Subscription.current_period_end.is_not(None), Subscription.current_period_end <= now)
                      .limit(500)
                )
                subs_list = list(subs)
                for sub in subs_list:
                    sub.status = "canceled"
                    # ensure free
                    user = await session.get(User, sub.user_id)
                    if user:
                        await ensure_free_subscription(session, user)
                await session.commit()
        except Exception as e:
            log.warning("sub_reaper error: %s", e)
        await asyncio.sleep(max(10, settings.SUB_REAPER_INTERVAL_SEC))


@app.get("/metrics")
async def metrics():
    return HTMLResponse(generate_latest().decode("utf-8"), media_type=CONTENT_TYPE_LATEST)


@app.get("/health")
async def health():
    return {"ok": True}

# ---------- Internal endpoints (used by Telegram bot) ----------
@app.post("/internal/upsert_user", dependencies=[Depends(require_service_key)], response_model=UserOut)
async def internal_upsert_user(body: UpsertUserIn):
    async with SessionLocal() as session:
        user = await repo.upsert_user(session, body.tg_user_id, body.tg_chat_id, body.username)
        return UserOut(tg_user_id=user.tg_user_id, tg_chat_id=user.tg_chat_id, username=user.username)

@app.get("/internal/plan/{tg_user_id}", dependencies=[Depends(require_service_key)])
async def internal_plan(tg_user_id: int):
    async with SessionLocal() as session:
        user = await repo.get_user_by_tg(session, tg_user_id)
        if not user:
            raise HTTPException(404, "User not found")
        sub, plan = await repo.get_plan_info(session, user)
        return {
            "plan": PlanOut(
                code=plan.code, name=plan.name, max_watches=plan.max_watches,
                min_interval_sec=plan.min_interval_sec, price_rub_month=plan.price_rub_month, max_rps=plan.max_rps
            ),
            "status": sub.status,
            "period_end": sub.current_period_end.isoformat() if sub.current_period_end else None
        }

@app.post("/internal/watch", dependencies=[Depends(require_service_key)], response_model=WatchOut)
async def internal_create_watch(body: WatchCreateIn):
    async with SessionLocal() as session:
        user = await repo.get_user_by_tg(session, body.tg_user_id)
        if not user:
            raise HTTPException(404, "User not found")
        try:
            w = await repo.create_watch(session, user, body.url, body.interval_sec)
        except ValueError as e:
            raise HTTPException(400, str(e))
        return WatchOut(id=w.id, url=w.url, interval_sec=w.interval_sec, enabled=w.enabled)

@app.get("/internal/watches/{tg_user_id}", dependencies=[Depends(require_service_key)], response_model=list[WatchOut])
async def internal_list_watches(tg_user_id: int):
    async with SessionLocal() as session:
        user = await repo.get_user_by_tg(session, tg_user_id)
        if not user:
            raise HTTPException(404, "User not found")
        watches = await repo.list_watches(session, user)
        return [WatchOut(id=w.id, url=w.url, interval_sec=w.interval_sec, enabled=w.enabled) for w in watches]

@app.delete("/internal/watch/{watch_id}", dependencies=[Depends(require_service_key)])
async def internal_delete_watch(watch_id: int, body: WatchDeleteIn):
    async with SessionLocal() as session:
        user = await repo.get_user_by_tg(session, body.tg_user_id)
        if not user:
            raise HTTPException(404, "User not found")
        ok = await repo.delete_watch(session, user, watch_id)
        return {"ok": ok}

@app.patch("/internal/watch/{watch_id}/interval", dependencies=[Depends(require_service_key)])
async def internal_set_interval(watch_id: int, body: WatchIntervalIn):
    async with SessionLocal() as session:
        user = await repo.get_user_by_tg(session, body.tg_user_id)
        if not user:
            raise HTTPException(404, "User not found")
        ok = await repo.set_interval(session, user, watch_id, body.interval_sec)
        return {"ok": ok}

# ---------- Payments (skeleton) ----------
# Для “самой простой кассы” в проде вы подключаете провайдера (ЮKassa/CloudPayments/Stripe etc.)
# Здесь сделана заглушка: создаём payment_id и отдаём "pay_url".

@app.post("/payments/create", dependencies=[Depends(require_service_key)], response_model=PaymentCreateOut)
async def payments_create(body: PaymentCreateIn):
    async with SessionLocal() as session:
        user = await repo.get_user_by_tg(session, body.tg_user_id)
        if not user:
            raise HTTPException(404, "User not found")
        plan = await session.scalar(sa.select(Plan).where(Plan.code == body.plan_code))
        if not plan:
            raise HTTPException(404, "Plan not found")

        # amount from plan
        amount_value = f"{float(plan.price_rub_month):.2f}"
        return_url = settings.PUBLIC_BASE_URL.rstrip("/") + "/payments/return"

        metadata = {
            "tg_user_id": str(body.tg_user_id),
            "plan_code": plan.code,
        }

        resp = await create_provider_payment(
            amount_value=amount_value,
            description=f"Avito Monitor PRO: {plan.name} (1 month)",
            return_url=return_url,
            metadata=metadata,
        )

        pay_url = resp.get("pay_url") or ""
        provider = resp.get("provider") or "stub"
        provider_pid = resp.get("provider_payment_id")

        # store payment record
        await repo.create_payment_record(
            session=session,
            user=user,
            plan=plan,
            provider=provider,
            amount_value=amount_value,
            pay_url=pay_url,
            provider_payment_id=provider_pid,
        )

        return PaymentCreateOut(payment_id=str(provider_pid or ""), pay_url=pay_url, plan_code=plan.code)



# ---------- YooKassa webhook ----------
# Для HTTP Basic Auth мерчантов: webhook настраивается в личном кабинете.
# ЮKassa рекомендует проверять подлинность уведомлений по статусу объекта или по IP-адресу отправителя.
# Мы делаем опциональную проверку IP allowlist + проверяем актуальный статус через API при необходимости.

YOOKASSA_ALLOWED_CIDRS = [
    "185.71.76.0/27",
    "185.71.77.0/27",
    "77.75.153.0/25",
    "77.75.156.11/32",
    "77.75.156.35/32",
    "77.75.154.128/25",
    "2a02:5180::/32",
]

def _ip_allowed(ip: str) -> bool:
    import ipaddress
    addr = ipaddress.ip_address(ip)
    for cidr in YOOKASSA_ALLOWED_CIDRS:
        if addr in ipaddress.ip_network(cidr, strict=False):
            return True
    return False

@app.post("/yookassa/webhook")
async def yookassa_webhook(request: Request):
    body = await request.json()
    event = body.get("event")
    obj = body.get("object") or {}
    payment_id = obj.get("id")
    metadata = obj.get("metadata") or {}

    client_ip = get_client_ip(request)
    if settings.YOOKASSA_VALIDATE_IP and client_ip and not _ip_allowed(client_ip):
        raise HTTPException(status_code=403, detail="IP not allowed")

    if event == "payment.succeeded" and payment_id:
        # verify status via YooKassa API (recommended)
        try:
            status_obj = await yk_get_payment(str(payment_id))
            if status_obj.get("status") != "succeeded":
                return {"ok": True}
        except Exception:
            # if verification fails, do not activate
            return {"ok": True}

        async with SessionLocal() as session:
            # mark payment succeeded (if we have it)
            await repo.mark_payment_succeeded(session, provider="yookassa", provider_payment_id=str(payment_id))

            # activate plan for user using metadata
            tg_user_id = metadata.get("tg_user_id")
            plan_code = metadata.get("plan_code")
            if tg_user_id and plan_code:
                user = await repo.get_user_by_tg(session, int(tg_user_id))
                if user:
                    plan = await session.scalar(sa.select(Plan).where(Plan.code == str(plan_code)))
                    if plan:
                        await repo.activate_plan_for_user(session, user_id=user.id, plan_id=plan.id, days=30)

    # important: reply 200
    return {"ok": True}


# ---------- Admin (simple HTML) ----------
@app.get("/admin", response_class=HTMLResponse, dependencies=[Depends(require_admin_key)])
async def admin_home(request: Request):
    async with SessionLocal() as session:
        users = int((await session.scalar(sa.select(sa.func.count(User.id)))) or 0)
        watches = int((await session.scalar(sa.select(sa.func.count(Watch.id)))) or 0)
        plans = await session.scalars(sa.select(Plan).order_by(Plan.id.asc()))
        return templates.TemplateResponse(
            "admin.html",
            {
                "request": request,
                "users": users,
                "watches": watches,
                "plans": list(plans),
            },
        )

def run():
    import uvicorn
    uvicorn.run("svc.api:app", host="0.0.0.0", port=8000, reload=False, proxy_headers=True, forwarded_allow_ips="*")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    run()
