from __future__ import annotations
import uuid

async def create_payment(amount_value: str, description: str, return_url: str, metadata: dict) -> dict:
    pid = str(uuid.uuid4())
    return {
        "provider": "stub",
        "provider_payment_id": pid,
        "pay_url": f"https://pay.example.com/{pid}",
        "raw": {"id": pid, "confirmation": {"confirmation_url": f"https://pay.example.com/{pid}"}, "metadata": metadata},
    }
