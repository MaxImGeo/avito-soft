from __future__ import annotations

import base64
import uuid
import httpx
from ..config import settings

YOOKASSA_API = "https://api.yookassa.ru/v3"

def _basic_auth_header(shop_id: str, secret: str) -> str:
    token = base64.b64encode(f"{shop_id}:{secret}".encode("utf-8")).decode("ascii")
    return f"Basic {token}"

async def create_payment(amount_value: str, description: str, return_url: str, metadata: dict) -> dict:
    """Create payment in YooKassa (redirect confirmation).

    Uses HTTP Basic Auth (shopId:secretKey) and Idempotence-Key header.
    """
    if not settings.YOOKASSA_SHOP_ID or not settings.YOOKASSA_SECRET_KEY:
        raise RuntimeError("YOOKASSA_SHOP_ID/YOOKASSA_SECRET_KEY not set")

    headers = {
        "Authorization": _basic_auth_header(settings.YOOKASSA_SHOP_ID, settings.YOOKASSA_SECRET_KEY),
        "Idempotence-Key": str(uuid.uuid4()),
        "Content-Type": "application/json",
    }

    payload = {
        "amount": {"value": f"{float(amount_value):.2f}", "currency": "RUB"},
        "capture": True,
        "confirmation": {"type": "redirect", "return_url": return_url},
        "description": description[:128],
        "metadata": metadata,
    }

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        r = await client.post(f"{YOOKASSA_API}/payments", headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()

    pay_url = data.get("confirmation", {}).get("confirmation_url") or ""
    return {
        "provider": "yookassa",
        "provider_payment_id": data.get("id"),
        "pay_url": pay_url,
        "raw": data,
    }

async def get_payment(payment_id: str) -> dict:
    if not settings.YOOKASSA_SHOP_ID or not settings.YOOKASSA_SECRET_KEY:
        raise RuntimeError("YOOKASSA_SHOP_ID/YOOKASSA_SECRET_KEY not set")
    headers = {
        "Authorization": _basic_auth_header(settings.YOOKASSA_SHOP_ID, settings.YOOKASSA_SECRET_KEY),
    }
    async with httpx.AsyncClient(timeout=httpx.Timeout(20.0)) as client:
        r = await client.get(f"{YOOKASSA_API}/payments/{payment_id}", headers=headers)
        r.raise_for_status()
        return r.json()
