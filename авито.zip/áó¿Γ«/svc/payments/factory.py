from __future__ import annotations

from ..config import settings

async def create_payment(amount_value: str, description: str, return_url: str, metadata: dict) -> dict:
    kind = (settings.PAYMENTS_PROVIDER or "stub").lower().strip()
    if kind == "yookassa":
        from .yookassa import create_payment as yk_create
        return await yk_create(amount_value, description, return_url, metadata)
    from .stub import create_payment as stub_create
    return await stub_create(amount_value, description, return_url, metadata)
