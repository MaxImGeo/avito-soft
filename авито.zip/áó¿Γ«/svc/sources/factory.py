from __future__ import annotations
from .base import Source
from .dummy import DummySource
from .apify import ApifySource
from ..config import settings

def build_source() -> Source:
    kind = (settings.SOURCE_KIND or "dummy").lower().strip()
    if kind == "apify":
        return ApifySource()
    return DummySource()
