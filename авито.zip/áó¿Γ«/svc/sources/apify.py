from __future__ import annotations

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from typing import List

from ..config import settings
from .base import Listing, Source

class ApifySource(Source):
    """Пример источника данных через Apify Actor API.

    Здесь НЕ делается “парсинг Avito напрямую”. Мы обращаемся к API провайдера данных.
    Ваша задача — иметь разрешённый источник/аккаунт/лимиты у провайдера.

    Документация: Apify Actor API (run-sync-get-dataset-items).
    """

    def __init__(self) -> None:
        if not settings.APIFY_TOKEN:
            raise RuntimeError("APIFY_TOKEN is required for SOURCE_KIND=apify")
        self.token = settings.APIFY_TOKEN
        self.actor_id = settings.APIFY_ACTOR_ID

    @retry(
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.NetworkError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
    )
    async def fetch_latest(self, search_url: str, limit: int) -> List[Listing]:
        url = f"https://api.apify.com/v2/acts/{self.actor_id}/run-sync-get-dataset-items?token={self.token}"

        payload = {
            "startUrls": [{"url": search_url}],
            "maxResults": int(limit),
        }

        async with httpx.AsyncClient(timeout=httpx.Timeout(60.0)) as client:
            r = await client.post(url, json=payload)
            r.raise_for_status()
            data = r.json()

        out: List[Listing] = []
        for item in data:
            item_id = str(item.get("AdID") or item.get("id") or item.get("ItemId") or "").strip()
            title = str(item.get("Title") or item.get("title") or "").strip()
            price = str(item.get("Price") or item.get("price") or "").strip()
            u = str(item.get("URL") or item.get("url") or "").strip()
            if not item_id or not u:
                continue
            if u.startswith("/"):
                u = "https://www.avito.ru" + u
            out.append(Listing(item_id=item_id, title=title or "Без названия", price=price or "—", url=u))

        return out
