from __future__ import annotations
from typing import List
from .base import Listing, Source

class DummySource(Source):
    async def fetch_latest(self, search_url: str, limit: int) -> List[Listing]:
        # Для теста без провайдера данных.
        return [
            Listing(item_id="demo-1", title="Demo item 1", price="1000", url="https://example.com/1"),
            Listing(item_id="demo-2", title="Demo item 2", price="2000", url="https://example.com/2"),
        ][:limit]
