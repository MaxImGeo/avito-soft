from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, List

@dataclass
class Listing:
    item_id: str
    title: str
    price: str
    url: str

class Source(Protocol):
    async def fetch_latest(self, search_url: str, limit: int) -> List[Listing]:
        ...
