from __future__ import annotations
from fastapi import Header, HTTPException
from .config import settings

async def require_service_key(x_service_key: str = Header(default="")) -> None:
    if x_service_key != settings.SERVICE_API_KEY:
        raise HTTPException(status_code=401, detail="Invalid service key")

async def require_admin_key(x_admin_key: str = Header(default="")) -> None:
    if x_admin_key != settings.ADMIN_API_KEY:
        raise HTTPException(status_code=401, detail="Invalid admin key")
