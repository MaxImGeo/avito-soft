from __future__ import annotations

import asyncio
from asyncio import Semaphore, gather
import logging

from aiogram import Bot
from aiolimiter import AsyncLimiter

import sqlalchemy as sa
from datetime import datetime, timezone

from .config import settings
from .db import SessionLocal, engine, Base
from .seed import seed_plans
from .sources.factory import build_source
from .rate_limit import RedisRateLimiter
from . import repo
from .models import Watch, User, Subscription, Plan

log = logging.getLogger("worker")

def fmt(item) -> str:
    return f"🆕 {item.title}\n💰 {item.price}\n🔗 {item.url}"

def utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)

async def get_watch_context(watch_id: int) -> tuple[int, int, int]:
    """Return (user_id, chat_id, max_rps) for watch."""
    async with SessionLocal() as session:
        row = await session.execute(
            sa.select(User.id, User.tg_chat_id, Plan.max_rps)
              .join(Watch, Watch.user_id == User.id)
              .join(Subscription, Subscription.user_id == User.id)
              .join(Plan, Plan.id == Subscription.plan_id)
              .where(Watch.id == watch_id, Subscription.status == "active")
        )
        r = row.first()
        if r:
            return int(r[0]), int(r[1]), int(r[2] or 1)
        # fallback
        row2 = await session.execute(sa.select(User.id, User.tg_chat_id).join(Watch, Watch.user_id == User.id).where(Watch.id == watch_id))
        u = row2.first()
        return int(u[0]), int(u[1]), 1

async def worker_loop() -> None:
    # ensure schema + plans
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with SessionLocal() as session:
        await seed_plans(session)

    bot = Bot(token=settings.BOT_TOKEN)
    source = build_source()

    # global provider rps
    global_limiter = AsyncLimiter(max_rate=max(1, settings.GLOBAL_FETCH_RPS), time_period=1)
    # per-user rps via redis
    per_user_rl = RedisRateLimiter(settings.REDIS_URL)

    # per-worker parallelism
    sem = Semaphore(30)  # tune

    async def handle_watch(w: Watch):
        async with sem:
            try:
                user_id, chat_id, max_rps = await get_watch_context(w.id)

                # per-user speed tier
                allowed = await per_user_rl.allow(user_id=user_id, limit_per_sec=max_rps)
                if not allowed:
                    # reschedule soon and release lock
                    async with SessionLocal() as session:
                        await repo.reschedule_watch_in(session, w.id, 1)
                    return

                async with global_limiter:
                    listings = await source.fetch_latest(w.url, limit=settings.MAX_RESULTS_PER_CHECK)

                payload = [
                    {"item_id": x.item_id, "title": x.title, "price": x.price, "url": x.url}
                    for x in listings
                ]
                if not payload:
                    async with SessionLocal() as session:
                        await repo.release_watch_success(session, w.id, w.interval_sec)
                    return

                payload = list(reversed(payload))
                async with SessionLocal() as session:
                    new_items = await repo.insert_items(session, w.id, payload)

                if new_items:
                    for it in new_items:
                        await bot.send_message(chat_id, fmt(it))

                async with SessionLocal() as session:
                    await repo.release_watch_success(session, w.id, w.interval_sec)

            except Exception as e:
                err = f"{type(e).__name__}: {e}"
                log.warning("watch %s error: %s", getattr(w, "id", "?"), err)
                async with SessionLocal() as session:
                    cur = await session.execute(sa.select(Watch.fail_count, Watch.interval_sec).where(Watch.id == w.id))
                    row = cur.first()
                    fail = int(row[0] or 0) + 1 if row else 1
                    interval = int(row[1] or w.interval_sec) if row else w.interval_sec
                    await repo.release_watch_error(session, w.id, interval, fail, err)

    while True:
        try:
            async with SessionLocal() as session:
                watches = await repo.claim_due_watches(
                    session=session,
                    worker_id=settings.WORKER_ID,
                    lock_ttl_sec=settings.WORKER_LOCK_TTL_SEC,
                    limit=settings.WORKER_BATCH,
                )

            if not watches:
                await asyncio.sleep(settings.WORKER_TICK_SEC)
                continue

            await gather(*[handle_watch(w) for w in watches])

        except Exception as e:
            log.exception("Worker loop crash: %s", e)
            await asyncio.sleep(2)

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    asyncio.run(worker_loop())

if __name__ == "__main__":
    main()
