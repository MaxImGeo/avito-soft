from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    BOT_TOKEN: str

    DATABASE_URL: str

    SERVICE_API_KEY: str
    ADMIN_API_KEY: str

    # Admin hardening
    # Comma-separated CIDRs or IPs (e.g. "1.2.3.4/32,10.0.0.0/8"). Empty = allow any.
    ADMIN_IP_ALLOWLIST: str = ""
    # Optional header-based bypass to skip IP restriction (still requires X-Admin-Key)
    ADMIN_BYPASS_KEY: str | None = None

    ADMIN_TG_IDS: str = ""

    SOURCE_KIND: str = "apify"  # apify | dummy

    APIFY_TOKEN: str | None = None
    APIFY_ACTOR_ID: str = "songd~avito-search-scraper"

    
    PAYMENTS_PROVIDER: str = "stub"  # yookassa | stub

    YOOKASSA_SHOP_ID: str | None = None
    YOOKASSA_SECRET_KEY: str | None = None
    PUBLIC_BASE_URL: str = "http://localhost:8000"
    REDIS_URL: str = "redis://localhost:6379/0"
    SUB_REAPER_INTERVAL_SEC: int = 60
    YOOKASSA_VALIDATE_IP: bool = False

    WORKER_ID: str = "worker-1"
    WORKER_BATCH: int = 100
    WORKER_LOCK_TTL_SEC: int = 120
    WORKER_TICK_SEC: float = 1.0

    GLOBAL_FETCH_RPS: int = 20
    MAX_RESULTS_PER_CHECK: int = 30

    def admin_tg_ids(self) -> set[int]:
        out: set[int] = set()
        for x in (self.ADMIN_TG_IDS or "").split(","):
            x = x.strip()
            if x.isdigit():
                out.add(int(x))
        return out

settings = Settings()
