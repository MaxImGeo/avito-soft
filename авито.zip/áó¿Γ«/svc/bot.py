from __future__ import annotations

import asyncio
import logging
import httpx

from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message

from .config import settings

log = logging.getLogger("bot")

API_BASE = "http://api:8000"
HEADERS = {"X-Service-Key": settings.SERVICE_API_KEY}

async def api_post(path: str, json_data: dict):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(API_BASE + path, headers=HEADERS, json=json_data)
        r.raise_for_status()
        return r.json()

async def api_get(path: str):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(API_BASE + path, headers=HEADERS)
        r.raise_for_status()
        return r.json()

async def api_delete(path: str, json_data: dict):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.request("DELETE", API_BASE + path, headers=HEADERS, json=json_data)
        r.raise_for_status()
        return r.json()

async def api_patch(path: str, json_data: dict):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.patch(API_BASE + path, headers=HEADERS, json=json_data)
        r.raise_for_status()
        return r.json()

def build() -> tuple[Bot, Dispatcher]:
    bot = Bot(token=settings.BOT_TOKEN)
    dp = Dispatcher()

    @dp.message(Command("start"))
    async def start(m: Message):
        if not m.from_user:
            return
        await api_post("/internal/upsert_user", {
            "tg_user_id": m.from_user.id,
            "tg_chat_id": m.chat.id,
            "username": m.from_user.username
        })
        await m.answer(
            " Avito Monitor PRO\n\n"
            "Команды:\n"
            "/add <url> [sec]\n"
            "/list\n"
            "/del <watch_id>\n"
            "/interval <watch_id> <sec>\n"
            "/plan\n"
            "/buy <free|standard|pro>\n"
        )

    @dp.message(Command("plan"))
    async def plan(m: Message):
        if not m.from_user:
            return
        data = await api_get(f"/internal/plan/{m.from_user.id}")
        p = data["plan"]
        await m.answer(
            f"💎 Ваш план: {p['name']} ({p['code']})\n"
            f"Ссылок: до {p['max_watches']}\n"
            f"Мин. интервал: {p['min_interval_sec']} сек\n"
            f"Цена: {p['price_rub_month']} ₽/мес\n"
                f"Скорость: до {p['max_rps']} req/sec"
        )

    @dp.message(Command("add"))
    async def add(m: Message):
        if not m.from_user:
            return
        parts = (m.text or "").split(maxsplit=2)
        if len(parts) < 2:
            await m.answer("Формат: /add <url> [sec]")
            return
        url = parts[1].strip()
        sec = 60
        if len(parts) == 3:
            try:
                sec = int(parts[2].strip())
            except ValueError:
                await m.answer("sec должен быть числом")
                return

        try:
            w = await api_post("/internal/watch", {
                "tg_user_id": m.from_user.id,
                "url": url,
                "interval_sec": sec
            })
        except httpx.HTTPStatusError as e:
            msg = e.response.text
            await m.answer(f"❌ Не добавлено: {msg}")
            return

        await m.answer(f"✅ Добавлено: #{w['id']} | interval={w['interval_sec']}s")

    @dp.message(Command("list"))
    async def list_(m: Message):
        if not m.from_user:
            return
        watches = await api_get(f"/internal/watches/{m.from_user.id}")
        if not watches:
            await m.answer("Пока нет ссылок. /add <url> 60")
            return
        lines = ["🧾 Ваши ссылки:"]
        for w in watches:
            lines.append(f"#{w['id']} | {w['interval_sec']}s | {w['url']}")
        await m.answer("\n".join(lines))

    @dp.message(Command("del"))
    async def del_(m: Message):
        if not m.from_user:
            return
        parts = (m.text or "").split(maxsplit=1)
        if len(parts) < 2 or not parts[1].strip().isdigit():
            await m.answer("Формат: /del <watch_id>")
            return
        watch_id = int(parts[1].strip())
        res = await api_delete(f"/internal/watch/{watch_id}", {"tg_user_id": m.from_user.id})
        await m.answer("🗑️ Удалено" if res.get("ok") else "Не найдено")

    @dp.message(Command("interval"))
    async def interval(m: Message):
        if not m.from_user:
            return
        parts = (m.text or "").split()
        if len(parts) != 3 or not parts[1].isdigit() or not parts[2].isdigit():
            await m.answer("Формат: /interval <watch_id> <sec>")
            return
        watch_id = int(parts[1])
        sec = int(parts[2])
        res = await api_patch(f"/internal/watch/{watch_id}/interval", {
            "tg_user_id": m.from_user.id,
            "interval_sec": sec
        })
        await m.answer("✅ Обновлено" if res.get("ok") else "Не найдено")

    @dp.message(Command("buy"))
    async def buy(m: Message):
        if not m.from_user:
            return
        parts = (m.text or "").split(maxsplit=1)
        if len(parts) != 2:
            await m.answer("Формат: /buy <free|standard|pro>")
            return
        plan_code = parts[1].strip()
        try:
            p = await api_post("/payments/create", {
                "tg_user_id": m.from_user.id,
                "plan_code": plan_code
            })
        except httpx.HTTPStatusError as e:
            await m.answer(f"❌ Ошибка: {e.response.text}")
            return
        await m.answer(f"💳 Оплата ({p['plan_code']}): {p['pay_url']}\nЕсли оплата прошла, план обновится после webhook.")

    return bot, dp

async def main():
    bot, dp = build()
    await dp.start_polling(bot)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    asyncio.run(main())
