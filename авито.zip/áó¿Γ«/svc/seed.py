from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone, timedelta

from .models import Plan, Subscription, User

DEFAULT_PLANS = [
    # code, name, max_watches, min_interval_sec, price_rub_month, max_rps
    ("free", "Free", 3, 60, 0, 1),
    ("standard", "Standard", 20, 30, 1990, 3),
    ("pro", "Pro", 200, 10, 4990, 10),
]

async def seed_plans(session: AsyncSession) -> None:
    for code, name, mw, mi, price, rps in DEFAULT_PLANS:
        exists = await session.scalar(sa.select(Plan).where(Plan.code == code))
        if not exists:
            session.add(Plan(code=code, name=name, max_watches=mw, min_interval_sec=mi, price_rub_month=price, max_rps=rps))
    await session.commit()

async def ensure_free_subscription(session: AsyncSession, user: User) -> Subscription:
    # active subscription?
    sub = await session.scalar(
        sa.select(Subscription).where(Subscription.user_id == user.id, Subscription.status == "active")
    )
    if sub:
        return sub

    free_plan = await session.scalar(sa.select(Plan).where(Plan.code == "free"))
    if not free_plan:
        raise RuntimeError("Free plan missing; seed_plans first")

    sub = Subscription(
        user_id=user.id,
        plan_id=free_plan.id,
        status="active",
        current_period_end=None,
    )
    session.add(sub)
    await session.commit()
    await session.refresh(sub)
    return sub
