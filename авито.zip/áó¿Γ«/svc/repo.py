from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone, timedelta

from .models import User, Plan, Subscription, Watch, Item, Payment
from .seed import ensure_free_subscription

def utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)

async def upsert_user(session: AsyncSession, tg_user_id: int, tg_chat_id: int, username: str | None) -> User:
    user = await session.scalar(sa.select(User).where(User.tg_user_id == tg_user_id))
    if user:
        user.tg_chat_id = tg_chat_id
        user.username = username
    else:
        user = User(tg_user_id=tg_user_id, tg_chat_id=tg_chat_id, username=username)
        session.add(user)
    await session.commit()
    await session.refresh(user)
    await ensure_free_subscription(session, user)
    return user

async def get_active_subscription(session: AsyncSession, user: User) -> tuple[Subscription, Plan]:
    sub = await session.scalar(sa.select(Subscription).where(Subscription.user_id == user.id, Subscription.status == "active"))
    if not sub:
        sub = await ensure_free_subscription(session, user)
    plan = await session.get(Plan, sub.plan_id)
    assert plan is not None
    return sub, plan

async def count_watches(session: AsyncSession, user_id: int) -> int:
    c = await session.scalar(sa.select(sa.func.count(Watch.id)).where(Watch.user_id == user_id))
    return int(c or 0)

async def create_watch(session: AsyncSession, user: User, url: str, interval_sec: int) -> Watch:
    _, plan = await get_active_subscription(session, user)
    # enforce limits
    if interval_sec < plan.min_interval_sec:
        interval_sec = plan.min_interval_sec

    current = await count_watches(session, user.id)
    if current >= plan.max_watches:
        raise ValueError(f"Plan limit: max_watches={plan.max_watches}")

    w = Watch(
        user_id=user.id,
        url=url,
        interval_sec=interval_sec,
        enabled=True,
        next_run_at=utcnow(),
    )
    session.add(w)
    await session.commit()
    await session.refresh(w)
    return w

async def list_watches(session: AsyncSession, user: User) -> list[Watch]:
    rows = await session.scalars(sa.select(Watch).where(Watch.user_id == user.id).order_by(Watch.id.desc()))
    return list(rows)

async def delete_watch(session: AsyncSession, user: User, watch_id: int) -> bool:
    res = await session.execute(sa.delete(Watch).where(Watch.id == watch_id, Watch.user_id == user.id))
    await session.commit()
    return (res.rowcount or 0) > 0

async def set_interval(session: AsyncSession, user: User, watch_id: int, interval_sec: int) -> bool:
    _, plan = await get_active_subscription(session, user)
    if interval_sec < plan.min_interval_sec:
        interval_sec = plan.min_interval_sec
    res = await session.execute(
        sa.update(Watch)
          .where(Watch.id == watch_id, Watch.user_id == user.id)
          .values(interval_sec=interval_sec)
    )
    await session.commit()
    return (res.rowcount or 0) > 0

async def claim_due_watches(session: AsyncSession, worker_id: str, lock_ttl_sec: int, limit: int) -> list[Watch]:
    now = utcnow()
    lock_until = now + timedelta(seconds=lock_ttl_sec)

    # Select IDs due and not locked
    ids = await session.scalars(
        sa.select(Watch.id)
          .where(
              Watch.enabled == True,
              Watch.next_run_at <= now,
              sa.or_(Watch.locked_until.is_(None), Watch.locked_until < now),
          )
          .order_by(Watch.next_run_at.asc())
          .limit(limit)
    )
    ids_list = list(ids)
    if not ids_list:
        return []

    # Lock them
    await session.execute(
        sa.update(Watch)
          .where(Watch.id.in_(ids_list))
          .values(locked_until=lock_until, locked_by=worker_id)
    )
    await session.commit()

    # Load locked watches
    watches = await session.scalars(sa.select(Watch).where(Watch.id.in_(ids_list)))
    return list(watches)

async def release_watch_success(session: AsyncSession, watch_id: int, interval_sec: int) -> None:
    now = utcnow()
    next_run = now + timedelta(seconds=interval_sec)
    await session.execute(
        sa.update(Watch)
          .where(Watch.id == watch_id)
          .values(
              next_run_at=next_run,
              locked_until=None,
              locked_by=None,
              fail_count=0,
              last_error=None,
              last_success_at=now,
          )
    )
    await session.commit()

async def release_watch_error(session: AsyncSession, watch_id: int, interval_sec: int, fail_count: int, err: str) -> None:
    now = utcnow()
    # simple backoff: min(interval*2^fail, 3600)
    backoff = min(interval_sec * (2 ** min(fail_count, 6)), 3600)
    next_run = now + timedelta(seconds=backoff)
    await session.execute(
        sa.update(Watch)
          .where(Watch.id == watch_id)
          .values(
              next_run_at=next_run,
              locked_until=None,
              locked_by=None,
              fail_count=fail_count,
              last_error=err[:4000],
          )
    )
    await session.commit()

async def insert_items(session: AsyncSession, watch_id: int, items: list[dict]) -> list[Item]:
    """Insert with ON CONFLICT DO NOTHING, return newly inserted Items."""
    from sqlalchemy.dialects.postgresql import insert as pg_insert

    stmt = pg_insert(Item).values([
        dict(
            watch_id=watch_id,
            item_id=i["item_id"],
            title=i["title"],
            price=i["price"],
            url=i["url"],
        )
        for i in items
    ])
    stmt = stmt.on_conflict_do_nothing(index_elements=["watch_id", "item_id"]).returning(Item.id)
    res = await session.execute(stmt)
    new_ids = [r[0] for r in res.fetchall()]
    await session.commit()
    if not new_ids:
        return []
    rows = await session.scalars(sa.select(Item).where(Item.id.in_(new_ids)).order_by(Item.id.asc()))
    return list(rows)

async def get_user_by_tg(session: AsyncSession, tg_user_id: int) -> User | None:
    return await session.scalar(sa.select(User).where(User.tg_user_id == tg_user_id))

async def get_plan_info(session: AsyncSession, user: User) -> tuple[Subscription, Plan]:
    return await get_active_subscription(session, user)


async def create_payment_record(session: AsyncSession, user: User, plan: Plan, provider: str, amount_value: str, pay_url: str, provider_payment_id: str | None) -> Payment:
    p = Payment(
        user_id=user.id,
        plan_id=plan.id,
        provider=provider,
        provider_payment_id=provider_payment_id,
        status="pending",
        amount_value=amount_value,
        currency="RUB",
        pay_url=pay_url,
    )
    session.add(p)
    await session.commit()
    await session.refresh(p)
    return p

async def mark_payment_succeeded(session: AsyncSession, provider: str, provider_payment_id: str) -> Payment | None:
    p = await session.scalar(sa.select(Payment).where(Payment.provider == provider, Payment.provider_payment_id == provider_payment_id))
    if not p:
        return None
    p.status = "succeeded"
    await session.commit()
    await session.refresh(p)
    return p

async def activate_plan_for_user(session: AsyncSession, user_id: int, plan_id: int, days: int = 30) -> Subscription:
    # cancel current active subs
    await session.execute(
        sa.update(Subscription)
          .where(Subscription.user_id == user_id, Subscription.status == "active")
          .values(status="canceled")
    )
    from datetime import timedelta
    end = utcnow() + timedelta(days=days)
    sub = Subscription(
        user_id=user_id,
        plan_id=plan_id,
        status="active",
        current_period_end=end,
    )
    session.add(sub)
    await session.commit()
    await session.refresh(sub)
    return sub


async def reschedule_watch_in(session: AsyncSession, watch_id: int, seconds: int) -> None:
    from datetime import timedelta
    now = utcnow()
    next_run = now + timedelta(seconds=max(1, int(seconds)))
    await session.execute(
        sa.update(Watch)
          .where(Watch.id == watch_id)
          .values(next_run_at=next_run, locked_until=None, locked_by=None)
    )
    await session.commit()

async def clamp_user_watches(session: AsyncSession, user_id: int, min_interval_sec: int, max_watches: int) -> None:
    """When plan changes, enforce interval and max watches by disabling extras."""
    # clamp intervals
    await session.execute(
        sa.update(Watch)
          .where(Watch.user_id == user_id, Watch.interval_sec < int(min_interval_sec))
          .values(interval_sec=int(min_interval_sec))
    )
    # disable extra watches (keep newest enabled)
    rows = await session.scalars(
        sa.select(Watch.id)
          .where(Watch.user_id == user_id, Watch.enabled == True)
          .order_by(Watch.id.desc())
    )
    ids = list(rows)
    if len(ids) > int(max_watches):
        to_disable = ids[int(max_watches):]
        await session.execute(
            sa.update(Watch)
              .where(Watch.id.in_(to_disable))
              .values(enabled=False)
        )
    await session.commit()
