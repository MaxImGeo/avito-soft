from __future__ import annotations

import time
import redis.asyncio as redis

class RedisRateLimiter:
    """Simple per-second counter limiter.

    allow(user_id, limit) returns True if under limit, else False.
    Uses INCR + EXPIRE on key 'rl:<user_id>:<epoch_sec>'.
    """

    def __init__(self, redis_url: str):
        self.r = redis.from_url(redis_url, encoding="utf-8", decode_responses=True)

    async def allow(self, user_id: int, limit_per_sec: int) -> bool:
        if limit_per_sec <= 0:
            return False
        sec = int(time.time())
        key = f"rl:{user_id}:{sec}"
        val = await self.r.incr(key)
        if val == 1:
            # expire a bit later
            await self.r.expire(key, 3)
        return int(val) <= int(limit_per_sec)
