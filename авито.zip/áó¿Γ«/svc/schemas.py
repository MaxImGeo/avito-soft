from __future__ import annotations
from pydantic import BaseModel, Field

class UpsertUserIn(BaseModel):
    tg_user_id: int
    tg_chat_id: int
    username: str | None = None

class UserOut(BaseModel):
    tg_user_id: int
    tg_chat_id: int
    username: str | None

class PlanOut(BaseModel):
    code: str
    name: str
    max_watches: int
    min_interval_sec: int
    price_rub_month: int
    max_rps: int

class WatchCreateIn(BaseModel):
    tg_user_id: int
    url: str
    interval_sec: int = Field(default=60, ge=1)

class WatchOut(BaseModel):
    id: int
    url: str
    interval_sec: int
    enabled: bool

class WatchIntervalIn(BaseModel):
    tg_user_id: int
    interval_sec: int = Field(ge=1)

class WatchDeleteIn(BaseModel):
    tg_user_id: int

class PaymentCreateIn(BaseModel):
    tg_user_id: int
    plan_code: str

class PaymentCreateOut(BaseModel):
    payment_id: str
    pay_url: str
    plan_code: str
