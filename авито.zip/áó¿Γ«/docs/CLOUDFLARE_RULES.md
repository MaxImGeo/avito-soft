# Cloudflare rules checklist (recommended)

This project can run behind Cloudflare proxy (orange cloud). For extra protection:

## 1) WAF / Firewall rules
- Block common scanners: `/wp-login.php`, `/xmlrpc.php`, `/.env`, `/.git`, `/phpmyadmin`, `/cgi-bin/`
- Rate limit endpoints:
  - `/yookassa/webhook` — allow only from YooKassa IPs (if you don't need Cloudflare here, you can bypass proxy)
  - `/metrics` — restrict by IP or require auth
- Optional geo restriction (if your audience is RU/KZ/CIS): allow only selected countries.

## 2) Cloudflare Access (Zero Trust) for /admin (best)
- Protect `/admin*` with Cloudflare Access (SSO) or Service Token.
- This is safer than exposing admin by header only.

## 3) True client IP
- Nginx reads `CF-Connecting-IP` and updates real IP (see v6/v7).
- Run `scripts/update_cloudflare_ips.sh` weekly.
