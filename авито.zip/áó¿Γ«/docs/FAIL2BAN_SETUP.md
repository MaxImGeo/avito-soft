# Fail2ban setup (host)

Fail2ban работает на **хосте**, а не внутри Docker.

## Install (Ubuntu/Debian)
```bash
sudo apt-get update -y
sudo apt-get install -y fail2ban
```

## Configure
1) Скопируй конфиги:
```bash
sudo mkdir -p /etc/fail2ban/filter.d
sudo cp fail2ban/jail.local /etc/fail2ban/jail.local
sudo cp fail2ban/filter.d/nginx-botsearch.conf /etc/fail2ban/filter.d/nginx-botsearch.conf
```

2) Убедись, что nginx пишет логи на хост в `/var/log/nginx/`.
   В нашем docker-compose мы по умолчанию пишем логи в контейнер.
   Для host-based fail2ban лучше поставить nginx **на хосте** или
   примонтировать лог-файлы наружу (advanced).

3) Запусти:
```bash
sudo systemctl enable --now fail2ban
sudo fail2ban-client status
sudo fail2ban-client status nginx-botsearch
```
