# Security checklist (VPS)

## Firewall (UFW) — minimal
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing

# SSH (change port if you want)
sudo ufw allow 22/tcp

# Web
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

sudo ufw enable
sudo ufw status
```

Notes:
- Do NOT open Postgres (5432) or Redis (6379) to the internet. They are internal Docker network services.
- If you use Cloudflare, you can optionally restrict 80/443 to Cloudflare IPs only (advanced).

## SSH hardening (recommended)
- disable password auth, use keys
- consider changing SSH port
- install fail2ban

## Backups
- Run `./scripts/backup_postgres.sh` daily (cron) and upload to external storage.

## Monitoring
- Use `/metrics` with Prometheus/Grafana
- Track error rates in `/admin/errors`

## Cloudflare-only 80/443 (ipset + iptables)
Если используешь Cloudflare proxy (orange cloud), можно закрыть 80/443 только под Cloudflare:

```bash
sudo ./scripts/setup_cloudflare_firewall.sh
```

Обновляй списки Cloudflare регулярно:
- systemd timer `cloudflare-ipset.timer` (в проекте)
