# v9 Admin domain & endpoint hardening

## Goals
- /metrics is not public on main domain
- /metrics and /admin are served on ADMIN_DOMAIN
- /yookassa/webhook is rate-limited at Nginx
- optional IP allowlist for webhook (allow_yookassa.conf)

## Required env
- DOMAIN=monitor.example.com
- ADMIN_DOMAIN=admin.monitor.example.com
- PUBLIC_BASE_URL=https://monitor.example.com

## Certificate
`scripts/init_letsencrypt.sh` now requests cert for both DOMAIN and ADMIN_DOMAIN.

## Nginx
- main domain: /metrics -> 404
- admin domain:
  - /admin -> proxied to API
  - /metrics -> basic auth (.htpasswd)
  - /health -> proxied to API

## Stronger option: Cloudflare Access
If you use Cloudflare Zero Trust, protect `https://ADMIN_DOMAIN/admin*` with Access.
